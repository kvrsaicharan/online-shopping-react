import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import {  Button,Navbar } from 'react-bootstrap'
import './App.css';

//import logo from './logo.svg';
//import "bootstrap/dist/css/bootstrap.min.css";
//import './App.css';
import Home from "./components/home.component";
import Products from "./components/products.component";
import Login from "./components/login.component";
import Clock from "./components/clock.component";
import ProductsList from "./components/productsList.component"


class App extends Component {
  render() {
    return (
      <Router>
       
        <div className="container">
        
        <nav className="navbar navbar-expand-lg navbar-light bg-info  ">
        <a className="navbar-brand" href="http://google.com"
        rel="noopener noreferrer" target="_blank">
        <img src="images/logo.png" width="30" height="30"
        alt="logo is missing"/>
        </a>
        
        <Link to="/home" 
        className="navbar-brand text-light  ">Brand</Link>
        <div className="collpase navbar-collapse">
        <ul className="navbar-nav mr-auto">
        <li className="navbar-item">
        <Link to="/home"
        className="nav-link text-light ">Home</Link>
        </li>
        <li className="navbar-item">
        <Link to="/home"
        className="nav-link text-light ">About</Link>
        </li>
        <li className="navbar-item">
        <Link to="/home"
        className="nav-link text-light ">Contact</Link>
        </li>
        <li className="navbar-item">
        <Link to="/home"
        className="nav-link text-light ">Gallary</Link>
        </li>
        <li className="navbar-item">
        <Link to="/products"
        className="nav-link text-light ">View Products</Link>
        </li>
        <li className="navbar-item">
        <Link to="/products"
        className="nav-link text-light "><i class="fas fa-shopping-cart"></i></Link>
        </li>
        </ul>
        
        <ul className="navbar-nav ml-auto">
        <li className="nav-item">
        <Link to="/login"
        className="nav-link  text-warning">
        <b>Login</b></Link>
        </li>
        </ul>
        </div>
        </nav>
  
        <br/>
        <Route path="/" exact component={Home}/>
        <Route path="/home" exact component={Home}/>
        <Route path="/products" exact component={Products}/>
        <Route path="/login" exact component={Login}/>
        <Route path="/products" exact component={ProductsList}/>
       
       
        <hr/>
        <div className="offset-lg-9 col-lg-3">
      <Clock/></div>
       
        </div>
        
        
    
        
      </Router>
    );
  }
}

export default App;
