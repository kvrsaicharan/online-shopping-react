import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import Products from './products.component'

    class Product extends Component{
        constructor(props) {
            super(props);
            
         
        }
    
            
        
        
        render(){
            return(
                <tr>
                         <td>{this.props.product.product_name}</td>
                         <td>{this.props.product.product_cost}</td>
                         
                      
                         
                      
                     </tr> 
            )
        }
    }
    export default class ProductsList extends Component {
        constructor(props) {
            super(props);
            this.state = { products: [], id: '' };
  
          
    
    
        }
        //life cycle hook
        componentDidMount() {
            axios.get('http://localhost:4000/products')
                .then(response => {
                    this.setState({ products: response.data });
                })
                .catch(function (error) {
                    console.log(error);
                })
        }
        productList() {
            return this.state.products.map(function (currentProduct, i) {
                return <Product product={currentProduct} key={i} />;
            })
        }
       
render() {
    return (
        <div className="container">
        <div className="row">
        <div className="col-lg-12">
            <h3 className="text-left text-primary">Products List </h3>
            <table className="table table-stripped"
              style={{ marginTop: 20 }} >
                <thead>
                    <tr className="text-left">
                        <th>Product Name</th>
                        <th>Product Cost</th>
                       
                        <button type="button" class="btn btn-info">
  Count <span class="badge badge-light"> {this.state.products.length}</span>

</button>
                        
                    </tr>
                </thead>
                <tbody>
                    {this.productList()}
                   
                </tbody>
            </table>
        </div>
    </div>
    </div>
    )
}
    }

