import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';

export default class Products extends Component {

     constructor(props) {
        super(props);
        
        this.state = { products: [], id: '' };

        this.onChangeProductName = this.onChangeProductName.bind(this);
        this.onChangeProductCost = this.onChangeProductCost.bind(this);
        //binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);
        // this.clearForm = this.clearForm.bind(this);
this.state={
    product_name:'',
    product_cost:'',

}
  
     
     }
    onChangeProductName(event) {
        this.setState({
            product_name: event.target.value
        });
    }
    onChangeProductCost(event) {
        this.setState({
            product_cost: event.target.value
        });
    }

    onSubmit(event) {
        event.preventDefault();

        const newProduct = {
            product_name: this.state.product_name,
            product_cost: this.state.product_cost
        }
     
        axios.post('http://localhost:4000/products/add', newProduct)
        .then(res => console.log(res.data));

        this.setState({
            product_name: '',
            product_cost: '',

        })
        Swal.fire("Added Successful");
        this.props.history.push('/products');
        window.location.reload();
    }
    
    clearForm(e) {
        e.preventDefault();
        this.setState({
            product_name: '',
            product_cost: '',

        })
    }
    clearForm(e){
        e.preventDefault()
        this.clear();
    }
    
     
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className=" col-lg-12">
                        <div style={{ marginTop: 10 }}>
                            <h3 className="text-primary">Manage Products</h3><br />
                            <form onSubmit={this.onSubmit}>
                           
                                <div className="form-group">
                             
                                    <label>Product Name</label>
                                    <input type="text"
                                        className="form-control"
                                        value={this.state.product_name}
                                        onChange={this.onChangeProductName} />
                                          
                                </div>
                            
                                <div className="form-group">
                                    <label>Product Cost :</label>
                                    <input type="text" 
                                        className="form-control"
                                        value={this.state.product_cost}
                                        onChange={this.onChangeProductCost} />
                                </div>

                                <div className="form-group">
                                    <input type="submit" value="Add New Product"
                                        className="btn btn-success" />&nbsp;&nbsp;
                      
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <hr />
            
            </div>
        )
    }
}
