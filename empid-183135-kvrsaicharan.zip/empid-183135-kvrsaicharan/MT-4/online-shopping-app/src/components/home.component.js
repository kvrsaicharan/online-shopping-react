import React, {Component} from 'react';
import '../App.js';
import '../App.css';

function Home(){
    return(
        <div className="row">
        <div className="col-lg-6">
        <marquee><h1 className="text-success">Online Shopping Page </h1></marquee>
        <hr/>
        <p className=" text-danger">
        Online shopping is convenient and can often save your money. 
         
        Buy what ever you want
        </p>
        <ul className="text-primary list-group">
        <li className="list-group-item">Groceries</li>
        <li className="list-group-item">Clothes</li>
        <li className="list-group-item">Gadgets</li>
        <li className="list-group-item">Kitchen products</li>
        <li className="list-group-item"></li>
      
       
       
        </ul>
        </div>
        <div className="col-lg-6  zoom">
        <img src="images/image.png" className="img-thumbnail body loading " width="500" height="500"
        alt="logo is missing"/>
        </div>
        </div>
    );
}
export default Home;
