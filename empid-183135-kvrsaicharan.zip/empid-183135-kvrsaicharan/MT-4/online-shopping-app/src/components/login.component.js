
import React, { Component } from 'react';
import Swal from 'sweetalert2';


class Login extends React.Component {
    constructor() {
        super();
        // this.state = {
        //     type: 'input',
        //     score: 'null'
        //   }
        //   this.showHide = this.showHide.bind(this);
       
        
        this.state = {
            fields: { email: '', password: '' },
            errors: {},
            formsValid: true
        }
        this.handleChange = this.handleChange.bind(this);
        this.submitLoginForm = this.submitLoginForm.bind(this);
    }
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields: fields
        });
        console.log(this.state.fields);
    }
    submitLoginForm(e) {
        e.preventDefault();
        if (this.validateForm()) {
            if (this.state.fields.email == "admin@gmail.com"
                && this.state.fields.password == "123456") {
                let fields = {};
                fields["email"] = "";
                fields["password"] = "";
                this.setState({ fields: fields });
                Swal.fire({
                    title:"login Successful!"});
                this.props.history.push('/products');
            }
            else {
                Swal.fire({
                    title:"Invalid username or password..!"});
            }
        }
    }
    validateForm() {
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;
        if (!fields["email"]) {
            formIsValid = false;
            errors["email"] = "Please enter your Email Id";
        }
        else if (typeof fields["email"] !== "undefined") {
            if (!(fields["email"]
                .match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i))) {
                formIsValid = false;
                errors["email"] = "Please enter valid email Id";
            }
        } else {
            errors["email"] = "";
        }
        if (!fields["password"]) {
            formIsValid = false;
            errors["password"] = "Please enter your Password";
        }
        else if (typeof fields["password"] !== "undefined") {
            if (!(fields["password"].length >=0)){
             
                formIsValid = false;
                errors["password"] = "Password is too short";
            }
        } else {
            errors["password"] = "";
        }
        this.setState({
            errors:errors,
            formIsValid:formIsValid
        });
        return formIsValid

    }
  
    
    // showHide(e){
    //   e.preventDefault();
    //   e.stopPropagation();
    //   this.setState({
    //     type: this.state.type === 'input' ? 'password' : 'input'
    //   })  
    // }
    
  
    
    render() {
       
   
        return (
            <div className="row">
                <div className="col-lg-6">
                
                    <h3 className="text-success">Login </h3>
                    <hr />
                    <form id="react" method="post" name="loginForm" onSubmit={this.submitLoginForm}>
                        <div className="form-group">
                        <i className="fa fa-user-circle"> </i>  <label>Email Id: </label>
                            
                               <input type="text"  name="email"
                                className="form-control "
                                value={this.state.fields.email}
                                onChange={this.handleChange}

                            />
                            <div className={this.state.errors.email ? 'alert alert-danger' : ''}>
                                {this.state.errors.email}</div>
                        </div>
                        <div className="form-group">
                        <i className="fa fa-key"></i> <label>Password: </label>
                        
                       
                            <input type="password" name="password" id="password"
                                className="form-control"
                                value={this.state.fields.password}
                                onChange={this.handleChange}
                    

                            />
                             {/* <input type={this.state.type}
                             className="password__input"  name="password" id="password"
                                className="form-control"
                                value={this.state.fields.password}
                                onChange={this.handleChange} />
                                <span className="password__show" onClick={this.showHide}>{this.state.type === 'input' ? 'Hide' : 'Show'}</span> */}

                           
                            <div className={this.state.errors.password ? 'alert alert-danger' : ''}>
                                {this.state.errors.password}</div>
                        </div>
                    
                        <div className="form-group">
                            <input type="submit"
                                className="btn btn-success" value="Login" />
                            {/*disabled={!this.state.formIsValid}*/}
                        </div>
                      
                    </form>
                </div>
                <div className="offset-lg-2 col-lg-4 shadow p-3 mb-5  rounded" >
<img src="images/login.png"/></div>
<div className="text-right offset-lg-12"><marquee>You can also login through 
 <i className="fab fa-facebook"></i>&nbsp;<i className="fab fa-instagram "></i></marquee></div>

            </div>
            
        );
    }
}
export default Login;