const mongoose=require('mongoose');
const Schema =mongoose.Schema;

let productList= new Schema({
    product_name:{
        type:String
    },
    product_cost:{
        type:String
    },
   
    product_completed:{
        type:Boolean
    },

});
module.exports=mongoose.model('Product',productList);