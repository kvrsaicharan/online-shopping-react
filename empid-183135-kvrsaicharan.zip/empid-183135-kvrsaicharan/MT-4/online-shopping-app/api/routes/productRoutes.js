const express = require('express');
let Product = require('../models/product.model');

const productRoutes = express.Router();
productRoutes.route('/').get(function(req,res) {
    Product.find(function(err,products) {
            if (err) {
                console.log(err);
            } else {
                res.json(products);
            }
        });
    
    });
    
    
    productRoutes.route('/:id').get(function (req, res) {
        let id = req.params.id;
        Product.findById(id, function (err, product) {
            res.json(product);
        });
    });
    productRoutes.route('/add')
        .post(function (req, res) {
            let product = new Product(req.body);
            product.save().then(product => {
                res.status(200).json({
                    'product': 'product added succesfully'
                })
                    .catch(err => {
                        res.status(400).send('adding new todo failed');
                    });
    
            });
        });
        module.exports=productRoutes;