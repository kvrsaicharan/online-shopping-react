const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const productRoutes=require('./routes/productRoutes');

const PORT = 4000;

const config=require('./config/db');
app.use(cors());
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

//connect with mongodb

mongoose.Promise=global.Promise;
mongoose.connect(config.DB, { useNewUrlParser: true }).then(
    ()=> {console.log("MongoDB database connection established succesfully");},
    err=>{console.log('cannot connect to database ' +err.stack);}

)

app.use('/products', productRoutes);
app.listen(PORT, function () {
    console.log("Server is running on port: " + PORT);
});

